# 后端接入与数据迁移方案

> 当前系统为纯前端原型，数据存于各用户浏览器 localStorage（key：`opc-weekly-v3`），按设备隔离。
> 要实现「管理端实时汇总、多人协同、历史集中留存」，必须接入后端。本文给出接口、数据库与迁移的完整设计。
> 详细论证见《OPC 周报系统技术方案》（项目外文档），本文为工程落地版。

## 一、推荐后端选型

| 方案 | 适合场景 | 说明 |
|------|----------|------|
| **微信云开发（首选）** | 正式小程序化 | 免服务器运维，自带 openid 鉴权，免费额度足够 27 团队 |
| **Cloudflare Workers + D1** | 保持纯 Web、H5 形态 | 与 Cloudflare Pages 同平台，全球边缘部署，免费额度充足 |
| 传统 Node/Express + SQLite | 校内自有服务器 | 需自行运维、备案、HTTPS |

下文以通用 REST 语义描述，任选其一实现均可。

## 二、数据库设计（5 张表）

```
teams             团队表
├── id            string  主键
├── name          string  团队名（对应前端 teams.js 中的 27 项）
├── leader        string  负责人
├── teacher       string  指导老师
├── openid        string  绑定的用户标识（web 方案可为注册 token）
├── status        string  active | quit    （退出不删数据，置 quit）
└── created_at    int     时间戳

weekly_plan       周计划表
├── id            string  主键
├── week_key      string  如 2026-W46
├── team_id       string  → teams.id
├── tasks         json    [{no, title, target}]
├── need          string  所需支持
├── submit_at     int     提交时间
├── is_late       bool    是否逾期（截止后提交）
└── UNIQUE(week_key, team_id)   ← 数据库层杜绝重复提交

weekly_progress   周进度表
├── id            string  主键
├── week_key      string
├── team_id       string
├── items         json    [{plan_no, percent, note}]
├── result        string  亮点成果
├── delay         string  未完成原因与补救
├── avg_percent   int     服务端计算，不接受前端传入
├── submit_at     int
├── is_late       bool
└── UNIQUE(week_key, team_id)

reminder_log      提醒记录表
└── week_key / team_id / type(plan|progress) / channel / sent_at / success

admins            管理员表
└── user_id / name / role(super|viewer)
```

## 三、API 接口清单（9 个）

统一返回 `{ code, msg, data }`；学生接口从登录态推导身份，**绝不接受前端传 teamId**。

| 方法 | 路径 | 角色 | 说明 |
|------|------|------|------|
| POST | `/api/bind` | 学生 | 绑定团队（body: teamId），写入映射 |
| GET  | `/api/me` | 学生 | 返回 { team, weekKey, planDone, progressDone, deadline } |
| POST | `/api/plan` | 学生 | 提交周计划；校验截止时间/重复（覆盖需 confirm 标记）|
| POST | `/api/progress` | 学生 | 提交进度；服务端计算 avg_percent |
| GET  | `/api/history?page=` | 学生 | 本团队历史提交（分页）|
| GET  | `/api/admin/dashboard?week=` | 管理员 | 四项指标 + 27 行明细 |
| GET  | `/api/admin/trend?weeks=12` | 管理员 | 多周趋势 |
| POST | `/api/admin/remind` | 管理员 | 批量催办，写 reminder_log |
| GET  | `/api/admin/export?week=` | 管理员 | 生成 xlsx/CSV 下载流 |

**鉴权规则**：
- 管理类接口第一行校验当前用户 ∈ admins 表，失败返回 403；
- 截止时间判断一律用**服务器时间**，防手机改时间；
- 所有写接口对 `week_key + team_id` 做唯一性校验。

## 四、前端改造点（迁移时需要调整的代码位置）

| 文件 | 现状 | 改造 |
|------|------|------|
| `js/app.js` 中的 `store.get/set` | 读写 localStorage | 替换为 `fetch('/api/...')`，保留本地缓存做离线兜底 |
| `pickTeam()` 选择团队 | 本地切换 | 首次选择调 `/api/bind`，之后由服务端记住身份 |
| `submitForm()` | 写本地 | 调 `/api/plan`、`/api/progress`，处理 `NEED_CONFIRM` 覆盖确认 |
| `renderAdmin()` | 读本地演示数据 | 调 `/api/admin/dashboard` |
| `exportCSV()` | 前端拼 CSV | 改为请求 `/api/admin/export` 下载流 |
| `js/config.js` 的 `ADMIN_PASS` | 前端密码 | **删除**，改服务端登录（账号密码或 openid 白名单）|
| `simulateWeek()` | 载入演示数据 | 上线后删除 |

UI、表单字段、看板交互全部保留，不动。

## 五、数据迁移方案（避免丢失）

**场景 1：从当前 localStorage 迁移到后端**

1. 学生端：各团队在旧页面点「导出 CSV」或直接重新提交（推荐，操作量小）；
2. 管理员端：如已有历史 CSV，通过新增的管理接口 `POST /api/admin/import` 批量导入，按 `week_key + team_name` 匹配 `teams.name`；
3. 导入时校验：团队名必须在 teams 表中存在；重复记录跳过并输出清单人工核对；
4. 迁移完成后旧 localStorage 数据保留不清除（作为个人备份），页面顶部提示"历史数据已迁移至服务器"。

**场景 2：换域名/换托管**

- localStorage 跟随域名存储，**换域名会导致学生本地缓存"丢失"**（数据仍在旧域名下）。后端化之后此问题自动消除；纯前端阶段换域名则需学生重新提交。

**场景 3：团队退出/新增**

- 只改 `teams.status = quit` / 插入新行，绝不做物理删除，保证历史周报可追溯（对应宋老师、贾东旭老师团队退出的处理原则）。

## 六、上线核对清单

- [ ] `js/config.js` 管理密码已修改或已改为服务端鉴权
- [ ] `weekly_plan` / `weekly_progress` 已建 UNIQUE(week_key, team_id) 索引
- [ ] 管理接口 403 实测通过（用普通用户身份调用）
- [ ] 截止时间用服务器时间（改本机时间无法绕过）
- [ ] CSV/Excel 导出乱码检查（CSV 需带 UTF-8 BOM）
- [ ] teams 表与 27 家在营名单核对一致，退出团队 status=quit
- [ ] 数据库自动备份策略已开启（每周至少一次）
