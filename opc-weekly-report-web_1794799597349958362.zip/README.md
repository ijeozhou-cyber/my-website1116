# OPC 社区周报收集系统

面向高职院校 OPC 社区（27 家在营学生团队）的每周双表收集系统：
**每周一收工作计划、每周四收进度汇报**，含团队端填表与管理端看板。

> 纯静态前端项目，无任何框架与外部依赖，可直接部署到 Cloudflare Pages / GitHub Pages / 任意静态托管。

---

## 一、功能清单

### 团队端
- 从 27 家在营团队中选择身份（支持绑定切换）
- 周一提交「本周工作计划」（核心任务、量化目标、所需支持）
- 周四提交「本周进度汇报」（逐项完成度、实际成果、补救安排）
- 提交后可回填修改覆盖；自动累积历史提交记录
- 浏览器存储被禁用时显示黄色提示条（无痕模式/隐私模式场景）

### 管理端（隐藏入口）
- 入口：**快速连点页面标题 3 次** → 输入管理密码（默认 `opc2026`，见 `js/config.js`）
- 四项统计：计划已交 / 进度已交 / 平均完成度 / 逾期未交
- 27 家团队红黄绿提交看板，点击查看完整内容
- 模拟数据一键载入（演示用）
- 一键催办逾期团队（原型阶段为提示，正式版接消息推送）
- 导出本周汇总 CSV（可用 Excel 直接打开，含 BOM 中文不乱码）

---

## 二、目录结构

```
opc-weekly-report-web/
├── index.html          # 入口页面（Cloudflare Pages 默认识别）
├── css/
│   └── style.css       # 全部样式（浅色主题，移动端适配）
├── js/
│   ├── teams.js        # 团队名单数据（27 家在营团队，改名单只改这里）
│   ├── config.js       # 全局配置（管理密码 ADMIN_PASS、存储 key）
│   └── app.js          # 全部业务逻辑（表单、看板、统计、导出、门禁）
├── docs/
│   └── backend-migration.md   # 接入后端的接口/数据库/数据迁移方案
├── README.md
└── _headers            # Cloudflare Pages 自定义响应头（可选）
```

## 三、本地运行

无需构建，任选其一：

```bash
# 方式 1：直接双击 index.html 用浏览器打开
# 方式 2：起一个本地静态服务
python -m http.server 8080
# 然后访问 http://localhost:8080
```

## 四、部署到 Cloudflare Pages

1. 把本目录推送到 GitHub 仓库（见第七节）；
2. Cloudflare Dashboard → **Workers & Pages** → **Create** → **Pages** → **Connect to Git**，选中该仓库；
3. 构建配置：
   - **Framework preset**: `None`
   - **Build command**: 留空
   - **Build output directory**: `/`（根目录）
4. 点 **Save and Deploy**，约 30 秒后得到 `https://<项目名>.pages.dev` 固定网址；
5.（可选）绑定自定义域名：项目 → **Custom domains**。

> GitHub Pages 同理：Settings → Pages → Source 选 `main` 分支根目录即可。

## 五、部署后必改配置

打开 `js/config.js`：

```js
const ADMIN_PASS = 'opc2026';   // ← 务必修改！
```

团队名单变动时改 `js/teams.js` 的 `TEAMS` 数组（顺序即学生端显示顺序）。

## 六、平台依赖检查结论

本项目代码 **100% 独立**，已核查无以下依赖：
- ❌ 无 WorkBuddy 平台接口 / SDK / 存储
- ❌ 无第三方 CDN、字体、图标请求
- ❌ 无后端 API 调用（`fetch` / `XMLHttpRequest` 均为 0 处）
- ❌ 无构建工具、无 npm 依赖

唯一的外部性是 **数据存储位置**：所有周报数据保存在各用户浏览器 `localStorage`（key `opc-weekly-v3`），按浏览器/设备隔离。这意味着：
- ✅ 迁移到任何静态托管 **零代码改动**；
- ⚠️ 管理端看不到学生真实提交（原型阶段的既定限制），多人协同集中汇总必须接入后端，方案见 `docs/backend-migration.md`。

原 WorkBuddy 托管的 `?sharecode=C7CJNEIYJD` 参数是旧托管平台的访问控制，迁移到 Cloudflare Pages 后不再需要，链接直接访问即可。

## 七、上传 GitHub

```bash
cd opc-weekly-report-web
git init
git add .
git commit -m "feat: OPC 社区周报收集系统 v1.2"
git branch -M main
git remote add origin https://github.com/<你的用户名>/opc-weekly-report.git
git push -u origin main
```

## 八、版本记录

| 版本 | 日期 | 变更 |
|------|------|------|
| v1.0 | 2026-11-12 | 初版：双表单 + 管理看板 + CSV 导出 |
| v1.1 | 2026-11-12 | 按 27 家在营团队名单更新；移除 5 家退出团队 |
| v1.2 | 2026-11-13 | 隐藏管理入口 + 密码门禁；存储异常提示条；苏冠卿→田天雪 |
| v1.3 | 2026-11-16 | 工程化拆分（css/js 独立文件），适配 Cloudflare Pages |
